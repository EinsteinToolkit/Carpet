/**
   The Nirvana file format provides an API 
   for reading and writing simulation data, and is
   a particular way of storing any kind of simulation data
   including its meta data using lower level file formats such as  e.g. HDF5. 
   High-level routines are offered
   for storing and retrieving data from Nirvana.
   
   Developer: Christian Reisswig
   Year: 2010
   License: lGPL
*/


#ifndef _NIRVANA_
#define _NIRVANA_


#include <vector>
#include <list>
#include <string>
#include <sstream>
#include <iostream>
#include <cassert>
#include <algorithm>

using namespace std;

namespace Nirvana {


typedef double fp;

// forward definition
class metadata;


/**
   This class represents
   the Nirvana data file API.
   It can be represented through a set of HDF5 files, xml,
   or some other data formats.
*/
class File
{
   public :
            /// Iterator to iterate over all datasets contained in the file.
	    class Iterator;
   
	    File(const string& filename_) : _filename(filename_) { }
	    
	    virtual ~File() { };
	    
	    /// open file
	    virtual void Open(const bool write_only = false, const int nfiles = -1) = 0;
	    /// close file
	    virtual void Close() = 0;
	    
	    /// return a vector of all times
	    virtual vector<fp>  GetTimes() = 0;
	    /// return a vector of all cycles
	    virtual vector<int> GetCycles() = 0;
	    /// return all variable names stored in the file
	    virtual vector<string> GetVarNames() = 0;
	    /// return all meshnames
	    virtual vector<string> GetMeshNames() = 0;
	    
	    /// Retrieve the number of components that share the same given
	    /// metadata.
	    virtual int GetNComponents(const metadata& by_identifier, const metadata& by_value) = 0;
	    
	    /// Return begin iterator object
	    Iterator Begin();
	    
	    /// Retrieve mesh metadata as provided by metadata md
	    virtual metadata GetMesh(const metadata& md) = 0;
	    
	    /// Get a buffer of data of type T as specified by metadata
	    template <typename T>
	    void GetField(const metadata& md, vector<T>& buffer) { }
	    
	    /// Write mesh meta-data
	    virtual void WriteMesh(const metadata& md, const int fnum) = 0;
	    
	    /// Write a dataset of type T as described by metadata
	    /// to file. This can be anything, e.g. also a coordinate system.
	    /// The type of data is entirely specified by the metadata object.
	    template <typename T>
	    void WriteField(const metadata& md, const vector <T>& buffer) { }
	    
   protected :
	    
	    string _filename;
	    
};


/**
   Iterator class for iterating over all datasets
*/
class File::Iterator
{
   public :
           Iterator() { }
           
           virtual ~Iterator() { }
};


} // namespace



#endif
