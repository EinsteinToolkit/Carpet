/**
   The Nirvana file format provides an API 
   for reading and writing simulation data, and is
   a particular way of storing any kind of simulation data
   including its meta data using HDF5. 
   High-level routines are offered
   to store and retrieve data from Nirvana.
   
   Developer: Christian Reisswig
   Year: 2010
   License: lGPL
*/


#ifndef _CarpetN5_
#define _CarpetN5_


#include "metadata.hh"
#include "nirvana.hh"
#include "H5Cpp.h"
#include <typeinfo>


using namespace std;
using namespace H5;

namespace Nirvana {

   
#define ERRCHECK(condition, msg) { if (!condition) cout << msg << endl; assert(condition); }
   

/**
   This class represents
   a CarpetN5 data file.
   This file is represented through a (set of)
   HDF5 files.
*/
class CarpetN5 : public File
{
   public :
	    /// Iterator to iterate over all datasets contained in the file.
            class Iterator;
            
            
	    /// Open files. If nfiles is -1, we open an existing file.
	    /// Otherwise, we create nfiles files.
	    CarpetN5(const string& filename_, 
	             const bool write_only = false, 
	             const int nfiles = -1, 
	             const bool overwrite = false, 
	             const string& prev_checkpoint = "");
	    
	    virtual ~CarpetN5();
	    
	    /// create a new set of files that are supposed to store the data
	    virtual void Create(const int nfiles);
	    
	    /// open set of existing files. If write_only flag is set, we 
	    /// do _not_ browse through cycles and previous checkpoints!
	    virtual void Open(const bool write_only = false, const int nfiles = -1);
	    
	    /// close file
	    virtual void Close();
	    
	    /// return a vector of all times
	    virtual vector<fp>  GetTimes();
	    /// return a vector of all cycles
	    virtual vector<int> GetCycles();
	    /// return all variable names stored in the file
            virtual vector<string> GetVarNames();
            /// return all meshnames
            virtual vector<string> GetMeshNames();
	    
	    /// Retrieve the number of components that share the same given
	    /// metadata.
	    virtual int GetNComponents(const metadata& by_identifier, const metadata& by_value);
	    
	    /// Return begin iterator object
            Iterator Begin(const metadata& by_identifier, const metadata& by_value, const bool all_checkpoints = true);
	    
	    /// Retrieve mesh as provided by metadata
	    virtual metadata GetMesh(const metadata& md);
	    
	    template <typename T>
	    void GetField(const metadata& md, vector<T>& buffer);
	    
	    /// Create group structure for mesh as described by metadata.
	    /// If fnum is positive, we only operate on the specific file number.
	    /// Otherwise we operate on the root file that contains symlinks to all the
	    /// necessary data contained in all files.
	    virtual void WriteMesh(const metadata& md, const int fnum = -1);
	    
	    template <typename T>
	    void WriteField(const metadata& md, const vector<T>& buffer, const int fnum = -1);
	    
   private :
	    /// assembles the file-name string
            string H5filename(const int i) const
            {
               ostringstream out;
	       if (files.size() > 1)
		  out << _basename << ".file_" << i << ".N5";
	       else
		  out << _basename << ".N5";
               return out.str();
            }
	    
	    /// assembles the file-name string
            string H5rootfilename() const
            {
               ostringstream out;
               out << _basename << ".root" << ".N5";
               return out.str();
            }
	    
	    void doWriteMesh(const metadata& md, const H5File& file);
	    
	    template <typename T>
	    void doWriteField(const metadata& md, const vector<T>& buffer, const H5File& file);
	    
	    
	    void doCreate(const int nfiles, const H5File& file);
	    
	    /// construct the name of the group
	    string getMeshGroupName(const metadata& md);
	    
	    /// construct the name of the group/dataset associated with the given metadata
	    string getName(const metadata& md);
	    
	    /// The number of H5 files involved in storing the data per processor
	    vector<H5File*> files;
	    
	    /// All other previous checkpoints
	    vector<CarpetN5*> checkpoints;
	    /// previous file only
	    CarpetN5* pFile;
	    
	    /// all valid cycles of this checkpoint
	    vector<int> _valid_cycles;
	    /// all valid times of this checkpoint
	    vector<fp> _valid_times;
	    
	    /// the base filename
	    string _basename;
	    /// File including complete path of previous checkpoint.
	    /// This can be used to recursively open past checkpoint files.
	    /// Hence there is no need for merging files.
	    string _prev_checkpoint;
};


/**
   Iterator class for iterating over all datasets based on the provided metadata
*/
class CarpetN5::Iterator
{
   public :
           Iterator() 
              : _by_identifier(metadata()), _by_value(metadata()), N5File(NULL), done(true)
           { }
           
           // Iterate over all metadata defined by identifier and
           // select only those defined by value.
           Iterator(const metadata& by_identifier, 
                    const metadata& by_value, 
                    const CarpetN5* N5File_, 
                    const bool all_checkpoints = true);
           
           virtual ~Iterator() { }
           
           // returns the metadata of the current object in file
           metadata operator*();
           
           // increment iterator
           Iterator& operator++();
           void operator++(int) { ++(*this); };
           
           /// query if iterator is done
           bool Done() const { return done; }
           
           const metadata& by_identifier() const { return _by_identifier; }
           const metadata& by_value() const { return _by_value; }
           
           void getMetadata();
           
           /// access nbame of current object
           string& current_objectname() { return _current_objectname; }
           
           /// return current H5iter grouplevel
           int current_H5iter_grouplevel() const { return _cur_H5iter_grouplevel; }
           
           /// return current grouplevel
           int grouplevel() const { return _grouplevel; }
           
           /// check if object identified by "fullname" conforms with provided metadata attributes by identifier
           /// In case it does not, the maximal grouplevel is decreased because all deeper levels
           /// must be invalid too.
           bool conforms_with_identifier(const metadata& md, const string& fullname);
           /// check if object identified by "fullname" conforms with provided metadata attributes by value
           bool conforms_with_value(const metadata& md, const string& fullname);

   private :
           /// add metadata of current object to complete metadata
           void addMetadata(const string& objname);
           
           /// set indices to object with the given metadata.
           void jumpToObject(const metadata& _by_value);
           
           /// helper for routine above
           template <typename T>
           void jumpToObjectHelper(const attribute<T>& a);
           
           /// metadata to be iterated over (non-value specific) 
	   const metadata& _by_identifier;
	   /// metadat to be selected only (value specific)
	   const metadata& _by_value;
	   /// CarpetN5 file
	   const CarpetN5* N5File;
	   /// corresponding root file that is iterated
	   H5File file;
	   /// metadata of current object
	   metadata _md;
	   /// name of current object in file
	   string _current_objectname;
	   /// current name of group in which we iterate
	   vector<string> _rootname;
	   /// indicate whether we are done or not
	   bool done;
	   /// iterator index for each grouplevel for H5iterate
	   vector<int> idx;
	   /// level in group hierarchy, ie 0 is root "/" group,
	   /// 1 is /comp=...", etc... 
	   /// This also selects the index component in the idx vector above.
	   int _grouplevel;
	   /// maximal grouplevel depth.
	   int maxgrouplevel;
	   
	   vector<int> n_rootlevel_objects;
	   
	   int _cur_H5iter_grouplevel;
	   
};



template <typename T>
void CarpetN5::GetField(const metadata& md, vector<T>& buffer)
{
      // We need the following attributes
   attribute<int, string> cycle;
   attribute<int, string> rl;
   attribute<int, string> map;
   attribute<int, string> comp;
   attribute<string, string> meshname;
   attribute<string> varname;
   attribute<string> vargroupname;
   attribute<string> vargrouptype;
   attribute<vector<int> > lsh;
   
   // Get attributes
   cycle        = md.QueryAttribute<int>("cycle");
   rl           = md.QueryAttribute<int>("reflevel");
   map          = md.QueryAttribute<int>("map");
   comp         = md.QueryAttribute<int>("comp");
   meshname     = md.QueryAttribute<string>("meshname");
   varname      = md.QueryAttribute<string>("varname");
   vargroupname = md.QueryAttribute<string>("vargroupname");
   vargrouptype = md.QueryAttribute<string>("vargrouptype");
   lsh          = md.QueryAttribute<vector<int> >("lsh");
   
   // check that all necessary metadata attributes are present
   ERRCHECK(cycle.valid(), "Did not provide cycle metadata!");
   ERRCHECK(rl.valid(), "Did not provide reflevel metadata!");
   ERRCHECK(map.valid(), "Did not provide map metadata!");
   ERRCHECK(comp.valid(), "Did not provide meshname metadata!");
   ERRCHECK(meshname.valid(), "Did not provide meshname metadata!");
   ERRCHECK(varname.valid(), "Did not provide varname metadata!");
   ERRCHECK(vargrouptype.valid(), "Did not provide vargrouptype metadata!");
   ERRCHECK(vargroupname.valid(), "Did not provide vargroupname metadata!");
   ERRCHECK(lsh.valid(), "Did not provide lsh metadata!");
   
   // assemble groupname string based on metadata
   string var_groupname = getName(md);

   // open root file and see in which file the dataset is stored
   H5File file;
   try
   {
      Exception::dontPrint();
      file = H5File(H5rootfilename(), H5F_ACC_RDWR);
   }
   // catch failure caused by the H5File operations
   catch( FileIException error )
   {
      error.printError();
      return;
   }

   // open group of variable
   Group group;
   try
   {
      group = file.openGroup(var_groupname);
   }
   catch( FileIException error )
   {
      error.printError();
      return;
   }
   
   // read file attribute
   Attribute H5attr = group.openAttribute("varname="+varname.value());
   int filenum;
   H5attr.read(PredType::NATIVE_INT, &filenum);
   
   // now we open the processor containing the file and
   // read it in
   try
   {
      Exception::dontPrint();
      files[filenum] = new H5File(H5filename(filenum), H5F_ACC_RDWR);
   }
   // catch failure caused by the H5File operations
   catch( FileIException error )
   {
      error.printError();
      return;
   }

   DataSet dataset = files[filenum]->openDataSet(var_groupname);
   DataSpace dataspace = dataset.getSpace();
   
   const int rank = dataspace.getSimpleExtentNdims();
   
   //vector<hsize_t> dims_out(rank, 1);
   //const int ndims = dataspace.getSimpleExtentDims( dims_out, NULL);
   
   // get hyperslab metainfo (if any)
   vector<int> offset(rank, 0);
   vector<int> stride(rank, 1);
   vector<int> count = lsh.value();
   attribute<vector<int> > iva;
   iva = md.QueryAttribute<vector<int> >("hyperslab-offset");
   if (iva.valid())
      offset = iva.value();
   iva = md.QueryAttribute<vector<int> >("hyperslab-stride");
   if (iva.valid())
      stride = iva.value();
   iva = md.QueryAttribute<vector<int> >("hyperslab-count");
   if (iva.valid())
      count = iva.value();

   
   // put everything to c-order
   vector<hsize_t> offset_c_order(rank, 0);
   vector<hsize_t> count_c_order(rank, 1);
   vector<hsize_t> stride_c_order(rank, 1);
   
   for (int d=0; d < rank; d++) {
      offset_c_order[d] = offset[rank-1-d];
      count_c_order[d]  = count[rank-1-d];
      stride_c_order[d] = stride[rank-1-d];
   }
      
   DataSpace memspace( rank, &count_c_order.front() );
   
   buffer.resize(memspace.getSimpleExtentNpoints());
   
   dataspace.selectHyperslab( H5S_SELECT_SET, &count_c_order.front(), &offset_c_order.front(), &stride_c_order.front() );
   
   if (typeid(T) == typeid(double))
      dataset.read( &buffer.front(), PredType::NATIVE_DOUBLE, memspace, dataspace );

   delete files[filenum];
}


template <typename T>
void CarpetN5::WriteField(const metadata& md, const vector<T>& buffer, const int fnum)
{
   // Decide to which file we write.
   // If fnum < 0 then we write the root file that contains
   // symlinks to all datasets from all processes
   H5File file;
   if (fnum < 0)
   {
      try
      {
	 Exception::dontPrint();
	 file = H5File(H5rootfilename(), H5F_ACC_RDWR);
      }
      // catch failure caused by the H5File operations
      catch( FileIException error )
      {
	 error.printError();
	 return;
      }
      // Write create symlinks in the root file 
      // to the file containing the dataset
      doWriteField<T>(md, vector<T>(0), file);
      
      return;
   }
   
   // ... otherwise we write the data to the specified file number.
   try
   {
      Exception::dontPrint();
      files[fnum] = new H5File(H5filename(fnum), H5F_ACC_RDWR);
   }
   // catch failure caused by the H5File operations
   catch( FileIException error )
   {
      error.printError();
      return;
   }
   
   attribute<int> filenum = md.QueryAttribute<int>("filenum");
   assert(filenum.valid()); 
   assert(filenum.value() == fnum);
   
   // Write mesh to specified filenumber
   doWriteField<T>(md, buffer, *files[fnum]);
   
   delete files[fnum];
   files[fnum] = NULL;
}



template <typename T>
void CarpetN5::doWriteField(const metadata& md, const vector<T>& buffer, const H5File& file)
{
   // We need the following attributes
   attribute<int, string> cycle;
   attribute<fp, string> time;
   attribute<int, string> rl;
   attribute<int, string> map;
   attribute<int, string> comp;
   attribute<int, string> filenum;
   attribute<vector<int>, string> lsh;
   attribute<vector<int>, string> iorigin;
   attribute<vector<fp>, string> origin;
   attribute<vector<fp>, string> delta;
   attribute<string, string> meshname;
   attribute<string, string> coordinates;
   attribute<string> varname;
   attribute<string> vargroupname;
   attribute<string> vargrouptype;
   
   // Get attributes
   filenum      = md.QueryAttribute<int>("filenum");
   cycle        = md.QueryAttribute<int>("cycle");
   rl           = md.QueryAttribute<int>("reflevel");
   map          = md.QueryAttribute<int>("map");
   comp         = md.QueryAttribute<int>("comp");
   time         = md.QueryAttribute<fp>("time");
   meshname     = md.QueryAttribute<string>("meshname");
   coordinates  = md.QueryAttribute<string>("coordinates");
   lsh          = md.QueryAttribute<vector<int> >("lsh");
   iorigin      = md.QueryAttribute<vector<int> >("iorigin");
   origin       = md.QueryAttribute<vector<fp> >("origin");
   delta        = md.QueryAttribute<vector<fp> >("delta");
   varname      = md.QueryAttribute<string>("varname");
   vargroupname = md.QueryAttribute<string>("vargroupname");
   vargrouptype = md.QueryAttribute<string>("vargrouptype");
   
   // check that all necessary metadata attributes are present
   ERRCHECK(filenum.valid(), "Did not provide filenum metadata!");
   ERRCHECK(cycle.valid(), "Did not provide cycle metadata!");
   ERRCHECK(rl.valid(), "Did not provide reflevel metadata!");
   ERRCHECK(map.valid(), "Did not provide map metadata!");
   ERRCHECK(comp.valid(), "Did not provide meshname metadata!");
   ERRCHECK(time.valid(), "Did not provide time metadata!");
   ERRCHECK(meshname.valid(), "Did not provide meshname metadata!");
   ERRCHECK(coordinates.valid(), "Did not provide coordinates metadata!");
   ERRCHECK(lsh.valid(), "Did not provide lsh metadata!");
   ERRCHECK(iorigin.valid(), "Did not provide iorigin metadata!");
   ERRCHECK(origin.valid(), "Did not provide origin metadata!");
   ERRCHECK(delta.valid(), "Did not provide delta metadata!");
   ERRCHECK(varname.valid(), "Did not provide varname metadata!");
   ERRCHECK(vargrouptype.valid(), "Did not provide vargrouptype metadata!");
   ERRCHECK(vargroupname.valid(), "Did not provide vargroupname metadata!");
   
   
   // assemble groupname string based on metadata
   string mesh_group_name = getMeshGroupName(md);
   
   ostringstream vargrouptype_groupname; 
   vargrouptype_groupname << "vargrouptype=" << vargrouptype.value();
   ostringstream vargroupname_groupname; 
   vargroupname_groupname << "vargroupname=" << vargroupname.value();
   ostringstream datasetname;
   datasetname << "varname=" << varname.value();
   
   // open group containg dataset
   Group group;
   try
   {
      group = file.openGroup(mesh_group_name);
   }
   catch( FileIException error )
   {
      error.printError();
      return;
   }
   
   // open/create type group
   Group g_vargrouptype;
   try
   {
      g_vargrouptype = group.openGroup(vargrouptype_groupname.str().c_str()); 
   }
   catch( GroupIException error )
   {
      // create new group for that vartype
      g_vargrouptype = group.createGroup(vargrouptype_groupname.str().c_str());
   }
   
   // open/create vargroupname group
   Group g_vargroupname;
   try
   {
      g_vargroupname = g_vargrouptype.openGroup(vargroupname_groupname.str().c_str()); 
   }
   catch( GroupIException error )
   {
      // create new group for that vargroupname
      g_vargroupname = g_vargrouptype.createGroup(vargroupname_groupname.str().c_str());
   }
   
   if (buffer.size() == 0)
   {
      // buffer is empty, so we create a a group with an attribute of the name of the variable that
      // holds as value the file number it is stored in.
      Group g_varname;
      try {
         g_varname = g_vargroupname.openGroup(datasetname.str().c_str());
      }
      catch( GroupIException error )
      {
         // create new group for that datasetname
         g_varname = g_vargroupname.createGroup(datasetname.str().c_str());
      }

      try {
         Exception::dontPrint();
         g_varname.removeAttr(datasetname.str().c_str());
      } 
      catch ( AttributeIException error ) { }
      Attribute H5attr = g_varname.createAttribute(datasetname.str().c_str(), PredType::NATIVE_INT, DataSpace());
      int i = filenum.value();
      H5attr.write(PredType::NATIVE_INT, &i);
      
      
      // let's go to the meshname grouplevel and also list the variable there
      // because the variable will live on the entire mesh and not just on the given map/reflevel/component
      // open group containg dataset
      metadata mesh_md;
      mesh_md << md.QueryAttribute<int>("cycle");
      mesh_md << md.QueryAttribute<int>("timelevel");
      mesh_md << md.QueryAttribute<string>("meshname");
      string mesh_group_name = getName(mesh_md);
      Group group;
      try
      {
	 group = file.openGroup(mesh_group_name);
      }
      catch( FileIException error )
      {
	 error.printError();
	 return;
      }

      // open/create type group
      Group g_vargrouptype;
      try
      {
	 g_vargrouptype = group.openGroup(vargrouptype_groupname.str().c_str()); 
      }
      catch( GroupIException error )
      {
	 // create new group for that variable type
	 g_vargrouptype = group.createGroup(vargrouptype_groupname.str().c_str());
	 
	 Attribute H5attr = g_vargrouptype.createAttribute(vargrouptype.identifier(), StrType(PredType::C_S1, vargrouptype.value().size()), DataSpace());
         const char* val = vargrouptype.value().c_str();
         H5attr.write(StrType(PredType::C_S1, vargrouptype.value().size()), val);
      }

      // open/create vargroupname group
      Group g_vargroupname;
      try
      {
	 g_vargroupname = g_vargrouptype.openGroup(vargroupname_groupname.str().c_str()); 
      }
      catch( GroupIException error )
      {
	 // create new group for that vargroup
	 g_vargroupname = g_vargrouptype.createGroup(vargroupname_groupname.str().c_str());
	 
	 Attribute H5attr = g_vargroupname.createAttribute(vargroupname.identifier(), StrType(PredType::C_S1, vargroupname.value().size()), DataSpace());
         const char* val = vargroupname.value().c_str();
         H5attr.write(StrType(PredType::C_S1, vargroupname.value().size()), val);
      }
      g_varname;
      try {
         g_varname = g_vargroupname.openGroup(datasetname.str().c_str());
      }
      catch( GroupIException error )
      {
         // create new group for that datasetname
         g_varname = g_vargroupname.createGroup(datasetname.str().c_str());
         
         Attribute H5attr = g_varname.createAttribute(varname.identifier(), StrType(PredType::C_S1, varname.value().size()), DataSpace());
         const char* val = varname.value().c_str();
         H5attr.write(StrType(PredType::C_S1, varname.value().size()), val);
      }
      
      
      return;
   }
   
   // ... otherwise we write the data to disk
   
   // first, we delete existing datasets
   try {
      Exception::dontPrint();
      g_vargroupname.unlink(datasetname.str().c_str());
   }
   catch ( GroupIException error ) { }
   
   // make sure the size of the data buffer matches the size as given by metadata
   int n = 1; for (int i=0; i < lsh.value().size(); ++i) n *= lsh.value()[i];
   assert(buffer.size() == n);
   
   // Create dataspace for the dataset in the file.
   int rank = lsh.value().size();
   hsize_t* dims = new hsize_t[rank];
   for (int i=0; i < rank; ++i) dims[rank-i-1] = lsh.value()[i];
   DataSpace fspace(rank, dims);
   delete [] dims;
   
   const T* databuffer = &buffer.front();
   if (typeid(T) == typeid(double))
   {
      DataSet dataset = g_vargroupname.createDataSet(datasetname.str().c_str(), PredType::NATIVE_DOUBLE, fspace);
      dataset.write(databuffer, PredType::NATIVE_DOUBLE);
   }
   
   if (typeid(T) == typeid(int))
   {
      DataSet dataset = g_vargroupname.createDataSet(datasetname.str().c_str(), PredType::NATIVE_INT, fspace);
      dataset.write(databuffer, PredType::NATIVE_INT);
   }
}



template <typename T>
void CarpetN5::Iterator::jumpToObjectHelper(const attribute<T>& a)
{
      ostringstream str;
      str << a.identifier() << "=" << a.value();
      _grouplevel++;
      _rootname[_grouplevel+1] = _rootname[_grouplevel] +"/"+ str.str();
      _cur_H5iter_grouplevel = _grouplevel;
      //cout << _rootname[_grouplevel] << endl;
      Group g = file.openGroup(_rootname[_grouplevel]);
      for (int i=0; i < g.getNumObjs(); ++i)
      {
         if (g.getObjnameByIdx(i) == str.str()) {
            idx[_grouplevel] = i;
            idx[_grouplevel-1]++;
            break;
         }
      }
}



} // namespace



#endif