/**
   The Nirvana file format provides an API 
   for reading and writing simulation data, and is
   a particular way of storing any kind of simulation data
   including its meta data using HDF5. 
   High-level routines are offered
   to store and retrieve data from Nirvana.
   
   Developer: Christian Reisswig
   Year: 2010
   License: lGPL
*/


#ifndef _METADATA_
#define _METADATA_

#include "nirvana.hh"


namespace Nirvana {





/**
   A dataset attribute.
   vT = value-type, iT = identifier-type
                        */
template <typename vT, typename iT = string>
class attribute
{
   public :
            attribute() : _valid(false) { }
            attribute(iT identifier_, const vT value_) : _identifier(identifier_), _value(value_), _valid(true) { }
            virtual ~attribute() { }
            
            vT    value()       const { return _value; }
            iT    identifier()  const { return _identifier; } 
            bool  valid()       const { return _valid; }
            
   private :
            bool _valid;
            vT   _value;
            iT   _identifier; 
};




/**
   A list of dataset attributes that
   form the metadata.
                                 */
class metadata
{
   public :
            metadata() { }
            virtual ~metadata() { }
            
            void append(const attribute<int>& attrib)
            {
               iattribs.push_back(attrib);
	       iattribs_iterator = iattribs.begin();
            }
            
            void append(const attribute<fp>& attrib)
            {
               fattribs.push_back(attrib);
	       fattribs_iterator = fattribs.begin();
            }
            
            void append(const attribute<vector<int> >& attrib)
            {
               ivect_attribs.push_back(attrib);
	       ivect_attribs_iterator = ivect_attribs.begin();
            }
            
            void append(const attribute<vector<fp > >& attrib)
            {
               fvect_attribs.push_back(attrib);
	       fvect_attribs_iterator = fvect_attribs.begin();
            }
            
            void append(const attribute<string>& attrib)
            {
               string_attribs.push_back(attrib);
	       string_attribs_iterator = string_attribs.begin();
            }
            
            void get_next(attribute<int>& attrib) const
            {
               if (iattribs.size() == 0 || iattribs_iterator == iattribs.end())
               {
                  attrib = attribute<int>();
                  return;
               }
//              if (iattribs_iterator == iattribs.end())
// 		  iattribs_iterator = iattribs.begin()
               attrib = *iattribs_iterator;
	       ++iattribs_iterator;
            }
            
            void get_next(attribute<fp>& attrib) const
            {
               if (fattribs.size() == 0 || fattribs_iterator == fattribs.end())
               {
                  attrib = attribute<fp>();
                  return;
               }
//                if (fattribs_iterator == fattribs.end())
// 		  fattribs_iterator = fattribs.begin()
	       attrib = *fattribs_iterator;
	       ++fattribs_iterator;
            }
            
            void get_next(attribute<vector<int> >& attrib) const
            {
               if (ivect_attribs.size() == 0 || ivect_attribs_iterator == ivect_attribs.end())
               {
                  attrib = attribute<vector<int> >();
                  return;
               }
//                if (ivect_attribs_iterator == ivect_attribs.end())
// 		  ivect_attribs_iterator = ivect_attribs.begin()
	       attrib = *ivect_attribs_iterator;
	       ++ivect_attribs_iterator;
            }
            
            void get_next(attribute<vector<fp> >& attrib) const
            {
               if (fvect_attribs.size() == 0 || fvect_attribs_iterator == fvect_attribs.end())
               {
                  attrib = attribute<vector<fp> >();
                  return;
               }
//                if (fvect_attribs_iterator == fvect_attribs.end())
// 		  fvect_attribs_iterator = fvect_attribs.begin()
	       attrib = *fvect_attribs_iterator;
	       ++fvect_attribs_iterator;
            }
            
            void get_next(attribute<string>& attrib) const
            {
               if (string_attribs.size() == 0 || string_attribs_iterator == string_attribs.end())
               {
                  attrib = attribute<string>();
                  return;
               }
//                if (strings_attribs_iterator == string_attribs.end())
// 		  string_attribs_iterator = string_attribs.begin()
	       attrib = *string_attribs_iterator;
	       ++string_attribs_iterator;
            }
            
            void reset_stream() const
            {
	       iattribs_iterator = iattribs.begin();
	       fattribs_iterator = fattribs.begin();
	       ivect_attribs_iterator = ivect_attribs.begin();
	       fvect_attribs_iterator = fvect_attribs.begin();
	       string_attribs_iterator = string_attribs.begin();
	    }
            
            template <typename T>
            attribute<T> QueryAttribute(const string& identifier_) const
            {
	       // make sure stream is ready for reading
	       reset_stream();
	       
	       attribute<T> a;
	       bool done = false;
	       while (!done)
	       {
		  get_next(a);
		  if (a.identifier() == identifier_) done = true;
		  if (!a.valid()) done = true;
	       }
	       reset_stream();
	       return a;
	    }
            
            int size() const
            {
               return (  iattribs.size()
                       + fattribs.size()
                       + ivect_attribs.size()
                       + fvect_attribs.size()
                       + string_attribs.size());
            }
            
            /// remove current attribute of type T
            /*template <typename T>
            void pop()
            {
               if (typeid(T) == typeid(int))
                  iattribs_iterator = iattribs.erase(iattribs_iterator);
               
               if (typeid(T) == typeid(fp))
                  fattribs_iterator = fattribs.erase(fattribs_iterator);
               
               if (typeid(T) == typeid(vector<int>))
                  ivect_attribs_iterator = ivect_attribs.erase(ivect_attribs_iterator);
              
               if (typeid(T) == typeid(vector<fp>))
                  fvect_attribs_iterator = fvect_attribs.erase(fvect_attribs_iterator);
               
               if (typeid(T) == typeid(string))
                  string_attribs_iterator = string_attribs.erase(string_attribs_iterator);
            }*/
            
            /// remove current attribute of type T
            /*template <typename T>
            void remove(const attribute<T>& a)
            {
               if (typeid(T) == typeid(int))
                  iattribs.remove(a);
               
               if (typeid(T) == typeid(fp))
                  fattribs.remove(a);
               
               if (typeid(T) == typeid(vector<int>))
                  ivect_attribs.remove(a);
              
               if (typeid(T) == typeid(vector<fp>))
                  fvect_attribs.remove(a);
               
               if (typeid(T) == typeid(string))
                  string_attribs.remove(a);
            }*/
            
   private :
            list<attribute<int,         string> > iattribs;
            list<attribute<fp ,         string> > fattribs;
            list<attribute<vector<int>, string> > ivect_attribs;
            list<attribute<vector<fp >, string> > fvect_attribs;
            list<attribute<string,      string> > string_attribs;
	    
	    // Iterators for each attribute
	    mutable list<attribute<int,         string> >::const_iterator iattribs_iterator;
	    mutable list<attribute<fp,          string> >::const_iterator fattribs_iterator;
	    mutable list<attribute<vector<int>, string> >::const_iterator ivect_attribs_iterator;
	    mutable list<attribute<vector<fp >, string> >::const_iterator fvect_attribs_iterator;
	    mutable list<attribute<string     , string> >::const_iterator string_attribs_iterator;
};



template <typename vT, typename iT>
inline metadata& operator<<(metadata& md, const attribute<vT, iT>& attrib)
{
   md.append(attrib);
   return md;
}


template <typename vT, typename iT>
inline const metadata& operator>>(const metadata& md, attribute<vT, iT>& attrib)
{
   md.get_next(attrib);
   return md;
}


inline metadata& operator<<(metadata& md, const metadata& md_in)
{
   attribute<int> ia;
   attribute<fp> fa;
   attribute<string> sa;
   attribute<vector<int> > iva;
   attribute<vector<double> > fva;

   md_in.reset_stream();

   do {
      md_in >> ia;
      if (ia.valid()) md.append(ia);
   } while (ia.valid());
   
   do {
      md_in >> fa;
      if (fa.valid()) md.append(fa);
   } while (fa.valid());
   
   do {
      md_in >> sa;
      if (sa.valid()) md.append(sa);
   } while (sa.valid());
   
   do {
      md_in >> iva;
      if (iva.valid()) md.append(iva);
   } while (iva.valid());
   
   do {
      md_in >> fva;
      if (fva.valid()) md.append(fva);
   } while (fva.valid());
   
   return md;
}




} // namespace






#endif


