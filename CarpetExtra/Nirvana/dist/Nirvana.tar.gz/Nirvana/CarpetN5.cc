/**
   The Nirvana file format provides an API 
   for reading and writing simulation data, and is
   a particular way of storing any kind of simulation data
   including its meta data using HDF5. 
   High-level routines are offered
   to store and retrieve data from Nirvana.
   
   Developer: Christian Reisswig
   Year: 2010
   License: lGPL
*/


#include "CarpetN5.hh"
#include "metadata.hh"


using namespace std;
using namespace H5;

namespace Nirvana {


CarpetN5::CarpetN5(const string& filename_, const bool write_only, const int nfiles, const bool overwrite, const string& prev_checkpoint)
   : File(filename_), _prev_checkpoint(prev_checkpoint), _valid_cycles(0), _valid_times(0), checkpoints(1, this), pFile(NULL)
{
  // try to find basename
  _basename = _filename;
  string extension(".N5");
  string root_extension(".root");
  string file_extension(".file_");
  
  size_t pos = _basename.rfind(extension);
  if (pos != string::npos)
     _basename.replace (pos, extension.length(),"");
  pos = _basename.rfind(root_extension);
  if (pos != string::npos)
    _basename.replace (pos, root_extension.length(),"");
  else
  {
    pos = _basename.rfind(file_extension);
    if (pos != string::npos)
      _basename.erase (pos);
  }

   if (nfiles < 0 || !overwrite)
      Open(write_only, nfiles);
   else if (overwrite)
      Create(nfiles);
}
	    

CarpetN5::~CarpetN5()
{
   if (pFile) delete pFile;
}



void CarpetN5::Create(const int nfiles)
{
   assert(nfiles > 0);
   
   // create nfiles HDF5 files
   files = vector<H5File*>(nfiles, NULL);
   
   for (int i=0; i < files.size(); ++i)
   {
      try
      {
	 Exception::dontPrint();
	 
	 files[i] = new H5File(H5filename(i), H5F_ACC_TRUNC);
      }
      // catch failure caused by the H5File operations
      catch( FileIException error )
      {
	 error.printError();
	 return;
      }

      doCreate(nfiles, *files[i]);
	 
      if (files[i]) delete files[i];
      files[i] = NULL;
   }
   
   // create root file
   H5File file;
   try
   {
      Exception::dontPrint();
      file = H5File(H5rootfilename(), H5F_ACC_TRUNC);
   }
   // catch failure caused by the H5File operations
   catch( FileIException error )
   {
      error.printError();
      return;
   }

   doCreate(nfiles, file);
}


void CarpetN5::doCreate(const int nfiles, const H5File& file)
{
   // write global metadata specifying how many files this data file
   // spans and create new group which contains this information.
   Group group(file.createGroup("Parameters and Global Attributes")); 

   Attribute H5attr = group.createAttribute("nfiles", PredType::NATIVE_INT, DataSpace());
   int val = nfiles;
   H5attr.write(PredType::NATIVE_INT, &val);
   
   if (_prev_checkpoint.size() > 0)
   {
      H5attr = group.createAttribute("Previous checkpoint", StrType(PredType::C_S1, _prev_checkpoint.size()), DataSpace());
      const char* cval = _prev_checkpoint.c_str();
      H5attr.write(StrType(PredType::C_S1, _prev_checkpoint.size()), cval);
   }
}


/**------------------------------------------------------------
    Open HDF5 file
*/
void CarpetN5::Open(const bool write_only, const int nfiles) 
{
   // Try to open root file.
   // If it doesn't exist, we create a new set of files.
   // Create root file now.
   H5File file;
   try
   {
      Exception::dontPrint();
      file = H5File(H5rootfilename(), H5F_ACC_RDWR);
   }
   // catch failure caused by the H5File operations
   catch( FileIException error )
   {
      if (nfiles < 0)
	 error.printError();
      else
      {
	 Create(nfiles);
	 file = H5File(H5rootfilename(), H5F_ACC_RDWR);
      }
   }

   // open global parameters group
   Group group;
   try
   {
      group = file.openGroup("Parameters and Global Attributes");
   }
   catch( FileIException error )
   {
      error.printError();
      return;
   }
   
   // find out how many files we have

   // look up number of files from root file
   int my_nfiles = -1;
   try
   {
      Exception::dontPrint();
      Attribute attrib = group.openAttribute("nfiles");
      attrib.read(PredType::NATIVE_INT, &my_nfiles);
   }
   catch( AttributeIException error )
   {
      if (nfiles <= 0)
      {
      error.printError();
      return;
      }
      else 
      files = vector<H5File*>(nfiles, NULL);
   }
   if (nfiles >= 0) assert(nfiles == my_nfiles);
   files = vector<H5File*>(my_nfiles, NULL);
   
   // if we only want to write, i.e. no parsing of timesteps
   // and previous checkpoints, we are done here
   if (write_only) return;
   
   // find out how many valid cycles we have by iterating over them
   attribute<int> acycles("cycle", 0);
   metadata md;
   md << acycles;
   int i = 0;
   for (Iterator iCycles = Begin(md, metadata(), false); !iCycles.Done(); ++iCycles, ++i)
   {
      _valid_cycles.resize(i+1);
      _valid_times.resize(i+1);
      metadata md = *iCycles;
      _valid_cycles[i] = md.QueryAttribute<int>("cycle").value();
      _valid_times[i] = md.QueryAttribute<fp>("time").value();
   }
   sort(_valid_cycles.begin(), _valid_cycles.end());
   sort(_valid_times.begin(), _valid_times.end());
 
 
   // open previous checkpoint (if any)
   char tmp[1000];
   try
   {
      Exception::dontPrint();
      Attribute attrib = group.openAttribute("Previous checkpoint");
      attrib.read(StrType(PredType::C_S1, 1000), &tmp);
   }
   catch( AttributeIException error )
   {
      return;
   }
   _prev_checkpoint = tmp;
   
   if (_prev_checkpoint.size() <= 0)
      return;
   
   // make sure the previous file is not set
   if (pFile) delete pFile;
   pFile = NULL;
   // open previous file
   pFile = new CarpetN5(_prev_checkpoint, false);
   
   // collect all previous files into one array
   // (the zeroth element is always the current file)
   i = 1;
   for (CarpetN5* current = pFile; current != NULL; current = current->pFile)
   {
      checkpoints.resize(i+1);
      checkpoints[i] = current;
   }
   
   // set range of validity for cycles and timesteps
   // of current checkpoint because they may overlap
   // We always discard the last few cycles of the previous checkpoint
   for (int i=1; i < checkpoints.size(); ++i)
   {
      for (int j=checkpoints[i]->_valid_cycles.size()-1; j >= 0; --j)
      {
         if (checkpoints[i]->_valid_cycles[j] < checkpoints[i-1]->_valid_cycles[0])
         {
            checkpoints[i]->_valid_cycles.resize(j-1);
            checkpoints[i]->_valid_times.resize(j-1);
            break;
         }
      }
   }
   
}


void CarpetN5::Close() 
{ 
}
	    


vector<fp> CarpetN5::GetTimes() 
{
   // if valid times has not been set
   // we have to parse the contents
   if (_valid_times.size() == 0)
      Open(false, files.size());
   

   if (checkpoints.size() == 1)
      return _valid_times;
   
   // collect all times from all checkpoints
   vector<fp> times;
   
   
   return times;
}

vector<int> CarpetN5::GetCycles() 
{
   // if valid times has not been set
   // we have to parse the contents
   if (_valid_cycles.size() == 0)
      Open(false, files.size());
   

   if (checkpoints.size() == 1)
      return _valid_cycles;

 
   vector<int> cycles;
   
   // Get all cycles from all checkpoints.
   
   
   
   return cycles;
}



vector<string> CarpetN5::GetVarNames()
{
}


vector<string> CarpetN5::GetMeshNames()
{
}


int CarpetN5::GetNComponents(const metadata& by_identifier, const metadata& by_value) 
{ 
}


metadata CarpetN5::GetMesh(const metadata& md)
{
}





void CarpetN5::WriteMesh(const metadata& md, const int fnum)
{
   
   // Decide to which file we write.
   // If fnum < 0 then we write the root file that contains
   // symlinks to all datasets from all processes
   if (fnum < 0)
   {
      H5File rfile;
      try
      {
	 Exception::dontPrint();
	 rfile = H5File(H5rootfilename(), H5F_ACC_RDWR);
      }
      // catch failure caused by the H5File operations
      catch( FileIException error )
      {
	 error.printError();
	 return;
      }
      
      // Write mesh to root file.
      // Since we only create a group structure with attributes,
      // we can re-use the actual call for writing the mesh.
      doWriteMesh(md, rfile);
      return;
   }
   
   // ... otherwise we write the mesh to the specified file number.
   try
   {
      Exception::dontPrint();
      files[fnum] = new H5File(H5filename(fnum), H5F_ACC_RDWR);
   }
   // catch failure caused by the H5File operations
   catch( FileIException error )
   {
      error.printError();
      return;
   }
   
   attribute<int> filenum = md.QueryAttribute<int>("filenum");
   assert(filenum.valid()); 
   assert(filenum.value() == fnum);
   
   // Write mesh to specified filenumber
   doWriteMesh(md, *files[fnum]);
   
   if (files[fnum]) delete files[fnum];
   files[fnum] = NULL;
   
}



void CarpetN5::doWriteMesh(const metadata& md, const H5File& file)
{
   // We need the following attributes
   attribute<int, string> cycle;
   attribute<fp, string> time;
   attribute<int, string> rl;
   attribute<int, string> tl;
   attribute<int, string> map;
   attribute<int, string> comp;
   attribute<int, string> filenum;
   attribute<vector<int>, string> lsh;
   attribute<vector<int>, string> iorigin;
   attribute<vector<int>, string> ghosts;
   attribute<vector<fp>, string> origin;
   attribute<vector<fp>, string> delta;
   attribute<string, string> meshname;
   attribute<string, string> coordinates;

   // Get attributes
   cycle       = md.QueryAttribute<int>("cycle");
   rl          = md.QueryAttribute<int>("reflevel");
   tl          = md.QueryAttribute<int>("timelevel");
   map         = md.QueryAttribute<int>("map");
   comp        = md.QueryAttribute<int>("comp");
   time        = md.QueryAttribute<fp>("time");
   meshname    = md.QueryAttribute<string>("meshname");
   coordinates = md.QueryAttribute<string>("coordinates");
   lsh         = md.QueryAttribute<vector<int> >("lsh");
   iorigin     = md.QueryAttribute<vector<int> >("iorigin");
   ghosts      = md.QueryAttribute<vector<int> >("ghosts");
   origin      = md.QueryAttribute<vector<fp> >("origin");
   delta       = md.QueryAttribute<vector<fp> >("delta");

   // check that all necessary metadata attributes are present
   ERRCHECK(cycle.valid(), "Did not provide cycle metadata!");
   ERRCHECK(rl.valid(), "Did not provide reflevel metadata!");
   ERRCHECK(tl.valid(), "Did not provide timelevel metadata!");
   ERRCHECK(map.valid(), "Did not provide map metadata!");
   ERRCHECK(comp.valid(), "Did not provide meshname metadata!");
   ERRCHECK(time.valid(), "Did not provide time metadata!");
   ERRCHECK(meshname.valid(), "Did not provide meshname metadata!");
   ERRCHECK(coordinates.valid(), "Did not provide coordinates metadata!");
   ERRCHECK(lsh.valid(), "Did not provide lsh metadata!");
   ERRCHECK(iorigin.valid(), "Did not provide iorigin metadata!");
   ERRCHECK(ghosts.valid(), "Did not provide ghosts metadata!");
   ERRCHECK(origin.valid(), "Did not provide origin metadata!");
   ERRCHECK(delta.valid(), "Did not provide delta metadata!");
   
   // Try to open mesh group.
   // If does not exist, we create one from scratch.
   // If it exists, we rewrite the attributes of the "comp" group in case they
   // have changed.
   Group g;
   try
   {
      g = file.openGroup(getMeshGroupName(md).c_str()); 
   }
   catch( FileIException error )
   {
      // need to creat that group  
      ostringstream cycle_groupname; 
      cycle_groupname << "cycle=" << cycle.value();
      ostringstream reflevel_groupname; 
      reflevel_groupname << "reflevel=" << rl.value();
      ostringstream tl_groupname; 
      tl_groupname << "timelevel=" << tl.value();
      ostringstream map_groupname; 
      map_groupname << "map=" << map.value();
      ostringstream mesh_groupname; 
      mesh_groupname << "meshname=" << meshname.value();
      ostringstream comp_groupname; 
      comp_groupname << "comp=" << comp.value();
      
      // try opening the associated cycle group
      Group g_cycle;
      try
      {
	 g_cycle = file.openGroup(cycle_groupname.str().c_str()); 
      }
      catch( FileIException error )
      {
	 // create new group for that timestep
	 g_cycle = file.createGroup(cycle_groupname.str().c_str()); 
	 
	 Attribute H5attr = g_cycle.createAttribute("cycle", PredType::NATIVE_INT, DataSpace());
	 int i = cycle.value();
	 H5attr.write(PredType::NATIVE_INT, &i);
	 H5attr = g_cycle.createAttribute("time", PredType::NATIVE_DOUBLE, DataSpace());
	 fp f = time.value();
	 H5attr.write(PredType::NATIVE_DOUBLE, &f);
      }
      
      // try opening the associated timelevel group
      Group g_tl;
      try
      {
	 g_tl = g_cycle.openGroup(tl_groupname.str().c_str()); 
      }
      catch( GroupIException error )
      {
	 // create new group for that timestep
	 g_tl = g_cycle.createGroup(tl_groupname.str().c_str()); 
	 
	 Attribute H5attr = g_tl.createAttribute("timelevel", PredType::NATIVE_INT, DataSpace());
	 int i = tl.value();
	 H5attr.write(PredType::NATIVE_INT, &i);
      }
      
      // try opening the associated mesh group
      Group g_mesh;
      try
      {
	 g_mesh = g_tl.openGroup(mesh_groupname.str().c_str()); 
      }
      catch( GroupIException error )
      {
	 // create new group for that mesh
	 g_mesh = g_tl.createGroup(mesh_groupname.str().c_str()); 
	 
	 Attribute H5attr = g_mesh.createAttribute(meshname.identifier(), StrType(PredType::C_S1, meshname.value().size()), DataSpace());
	 const char* val = meshname.value().c_str();
	 H5attr.write(StrType(PredType::C_S1, meshname.value().size()), val);
      }
      
      // try opening the associated map group
      Group g_map;
      try
      {
	 g_map = g_mesh.openGroup(map_groupname.str().c_str()); 
      }
      catch( GroupIException error )
      {
	 // create new group for that map
	 g_map = g_mesh.createGroup(map_groupname.str().c_str()); 
	 
	 Attribute H5attr = g_map.createAttribute("map", PredType::NATIVE_INT, DataSpace());
	 int i = map.value();
	 H5attr.write(PredType::NATIVE_INT, &i);
      }
      
      // try opening the associated reflevel group
      Group g_rl;
      try
      {
	 g_rl = g_map.openGroup(reflevel_groupname.str().c_str()); 
      }
      catch( GroupIException error )
      {
	 // create new group for that reflevel
	 g_rl = g_map.createGroup(reflevel_groupname.str().c_str());
	 
	 Attribute H5attr = g_rl.createAttribute("reflevel", PredType::NATIVE_INT, DataSpace());
	 int i = rl.value();
	 H5attr.write(PredType::NATIVE_INT, &i); 
      } 
      // try opening the associated component group
      try
      {
	 g = g_rl.openGroup(comp_groupname.str().c_str()); 
      }
      catch( GroupIException error )
      {
	 // create new group for that component
	 g = g_rl.createGroup(comp_groupname.str().c_str()); 
	 
	 Attribute H5attr = g.createAttribute("comp", PredType::NATIVE_INT, DataSpace());
	 int i = comp.value();
	 H5attr.write(PredType::NATIVE_INT, &i);
      }
   }

   // ok, group exists now.
   // Write grid-specific attributes corresponding to that group.
   // But first we remove existing attributes.
   try
   {
      Exception::dontPrint();
      g.removeAttr(lsh.identifier());
   }
   catch( AttributeIException error )
   {
      // Do nothing
   }
   try
   {
      Exception::dontPrint();
      g.removeAttr(iorigin.identifier());
   }
   catch( AttributeIException error )
   {
      // do nothing, if attribute was not found
   }
   try
   {
      Exception::dontPrint();
      g.removeAttr(origin.identifier());
   }
   catch( AttributeIException error )
   {
      // do nothing, if attribute was not found
   }
   try
   {
      Exception::dontPrint();
      g.removeAttr(delta.identifier());
   }
   catch( AttributeIException error )
   {
      // do nothing, if attribute was not found
   }
   try
   {
      Exception::dontPrint();
      g.removeAttr(coordinates.identifier());
   }
   catch( AttributeIException error )
   {
      // do nothing, if attribute was not found
   }
   try
   {
      Exception::dontPrint();
      g.removeAttr(ghosts.identifier());
   }
   catch( AttributeIException error )
   {
      // do nothing, if attribute was not found
   }
 
   hsize_t dim = lsh.value().size();
   Attribute H5attr = g.createAttribute(lsh.identifier(), PredType::NATIVE_INT, DataSpace(1, &dim));
   int* val = new int[dim];
   for (int d=0; d < dim; d++)
      val[d] = lsh.value()[d];
   H5attr.write(PredType::NATIVE_INT, val);
   delete [] val;
   
   dim = iorigin.value().size();
   H5attr = g.createAttribute(iorigin.identifier(), PredType::NATIVE_INT, DataSpace(1, &dim));
   val = new int[dim];
   for (int d=0; d < dim; d++)
      val[d] = iorigin.value()[d];
   H5attr.write(PredType::NATIVE_INT, val);
   delete [] val;
   
   dim = ghosts.value().size();
   H5attr = g.createAttribute(ghosts.identifier(), PredType::NATIVE_INT, DataSpace(1, &dim));
   val = new int[dim];
   for (int d=0; d < dim; d++)
      val[d] = ghosts.value()[d];
   H5attr.write(PredType::NATIVE_INT, val);
   delete [] val;
   
   dim = origin.value().size();
   H5attr = g.createAttribute(origin.identifier(), PredType::NATIVE_DOUBLE, DataSpace(1, &dim));
   fp* fval = new fp[dim];
   for (int d=0; d < dim; d++)
      fval[d] = origin.value()[d];
   H5attr.write(PredType::NATIVE_DOUBLE, fval);
   delete [] fval;
   
   dim = delta.value().size();
   H5attr = g.createAttribute(delta.identifier(), PredType::NATIVE_DOUBLE, DataSpace(1, &dim));
   fval = new fp[dim];
   for (int d=0; d < dim; d++)
      fval[d] = delta.value()[d];
   H5attr.write(PredType::NATIVE_DOUBLE, fval);
   delete [] fval;
   
   H5attr = g.createAttribute(coordinates.identifier(), StrType(PredType::C_S1, coordinates.value().size()), DataSpace());
   const char* cval = coordinates.value().c_str();
   H5attr.write(StrType(PredType::C_S1, coordinates.value().size()), cval);
}



string CarpetN5::getMeshGroupName(const metadata& md)
{
   ostringstream out;
   
   attribute<int, string> cycle;
   attribute<int, string> rl;
   attribute<int, string> tl;
   attribute<int, string> map;
   attribute<int, string> comp;
   attribute<string, string> meshname;
   
   // Get attributes
   cycle        = md.QueryAttribute<int>("cycle");
   tl           = md.QueryAttribute<int>("timelevel");
   rl           = md.QueryAttribute<int>("reflevel");
   map          = md.QueryAttribute<int>("map");
   comp         = md.QueryAttribute<int>("comp");
   meshname     = md.QueryAttribute<string>("meshname");
   
   // check that all necessary metadata attributes are present
   ERRCHECK(cycle.valid(), "Did not provide cycle metadata!");
   ERRCHECK(tl.valid(), "Did not provide reflevel metadata!");
   ERRCHECK(rl.valid(), "Did not provide reflevel metadata!");
   ERRCHECK(map.valid(), "Did not provide map metadata!");
   ERRCHECK(comp.valid(), "Did not provide meshname metadata!");
   ERRCHECK(meshname.valid(), "Did not provide meshname metadata!");
   
   out << "/cycle=" << cycle.value() 
       << "/timelevel=" << tl.value()
       << "/meshname=" << meshname.value()
       << "/map=" << map.value()
       << "/reflevel=" << rl.value()
       << "/comp=" << comp.value();
   
   return out.str();
}



string CarpetN5::getName(const metadata& md)
{
   ostringstream out;
   
   attribute<int, string> cycle;
   attribute<int, string> rl;
   attribute<int, string> tl;
   attribute<int, string> map;
   attribute<int, string> comp;
   attribute<string, string> meshname;
   attribute<string> varname;
   attribute<string> vargroupname;
   attribute<string> vargrouptype;
   
   // Get attributes
   cycle        = md.QueryAttribute<int>("cycle");
   tl           = md.QueryAttribute<int>("timelevel");
   rl           = md.QueryAttribute<int>("reflevel");
   map          = md.QueryAttribute<int>("map");
   comp         = md.QueryAttribute<int>("comp");
   meshname     = md.QueryAttribute<string>("meshname");
   varname      = md.QueryAttribute<string>("varname");
   vargroupname = md.QueryAttribute<string>("vargroupname");
   vargrouptype = md.QueryAttribute<string>("vargrouptype");
   
   // check which metadata attributes are present
   if (cycle.valid()) out << "/cycle=" << cycle.value();
   if (tl.valid()) out << "/timelevel=" << tl.value();
   if (meshname.valid()) out << "/meshname=" << meshname.value();
   if (map.valid()) out << "/map=" << map.value();
   if (rl.valid()) out << "/reflevel=" << rl.value();
   if (comp.valid()) out << "/comp=" << comp.value();
   if (vargrouptype.valid()) out << "/vargrouptype=" << vargrouptype.value();
   if (vargroupname.valid()) out << "/vargroupname=" << vargroupname.value();
   if (varname.valid()) out << "/varname=" << varname.value();
   
   return out.str();
}



CarpetN5::Iterator CarpetN5::Begin(const metadata& by_identifier, const metadata& by_value, const bool all_checkpoints)
{
   return CarpetN5::Iterator(by_identifier, by_value, this, all_checkpoints);
}



static herr_t H5iter(hid_t group_id, const char *member_name, void *operator_data)
{
   CarpetN5::Iterator* iter = (CarpetN5::Iterator*) operator_data;
   char   rootname[1000];
   string fullname;
   H5G_stat_t object_info;
   
   // build the full name for the current object to process
   H5Iget_name(group_id, rootname, 1000);
   string str1(rootname);
   string str2(member_name);
   
   if (str1 == "/")
      fullname = str1+str2;
   else
      fullname = str1+"/"+str2;
   
   iter->current_objectname() = fullname;
   
   //cout << "H5iter: " << fullname << ", " << iter->current_H5iter_grouplevel() << endl;
   
   // only do analysis on this object if we are on the requested grouplevel!
   if (iter->current_H5iter_grouplevel() != iter->grouplevel())
      return 1;
   
   //cout << "H5iter ready: " << fullname << ", " << iter->current_H5iter_grouplevel() << endl;
   
   // check if fullname contains all identifiers that were requested in 'valid' metadata
   if (!iter->conforms_with_identifier(iter->by_identifier(), fullname))
   {
      //cout << "not valid!" << endl;
      return 2;
   }
   
   // check if fullname contains the values of all 'strict' metadata vlues that were reqeusted
   if (!iter->conforms_with_value(iter->by_value(), fullname))
   {
      return 2;
   }
   
   // we have an object that meets all requirements
   // Let's add the objects metadata
   
   // get object info
   H5Gget_objinfo (group_id, fullname.c_str(), 0, &object_info);
   
   
   if (object_info.type == H5G_DATASET)
   {
      // return success
      return 1;
   }
   if (object_info.type == H5G_GROUP)
   {
      // get metadata for current object
      iter->getMetadata();
      
      // return success
      return 1;
   }
   
   
   return 0;
}




CarpetN5::Iterator::Iterator(const metadata& by_identifier, const metadata& by_value, const CarpetN5* N5File_, const bool all_checkpoints)
   : _by_identifier(by_identifier), _by_value(by_value), N5File(N5File_), _current_objectname("/"), done(false),
     _grouplevel(0), idx(vector<int>(10, 0)), n_rootlevel_objects(vector<int>(10, 0)),
     _rootname(vector<string>(10, "/")), _cur_H5iter_grouplevel(0)
{
    // open root file 
   try
   {
      Exception::dontPrint();
      file = H5File(N5File->H5rootfilename(), H5F_ACC_RDWR);
   }
   // catch failure caused by the H5File operations
   catch( FileIException error )
   {
      error.printError();
   }
   
   // there are maximally 8 group levels
   maxgrouplevel = 8;
   
   jumpToObject(_by_value);
   
   // get first element
   ++(*this);
}



metadata CarpetN5::Iterator::operator*()
{
   return _md;
}





CarpetN5::Iterator& CarpetN5::Iterator::operator++()
{
   // Continue to iterate over elements on the same grouplevel.
   // Each call to iterElems will
   // increase the idx by one. If iterElems returned 0 or threw an
   // exception, all elements on the current grouplevel have been iterated over.
   // We then have to increase the grouplevel.
   //string tmp = _current_objectname;
   int ret;
   try {
      do {
         ret = file.iterateElems(_rootname[_grouplevel], &idx[_grouplevel], H5iter, this); 
      } while (ret == 2);
      //cout << "maxgrouplevel = " << maxgrouplevel << endl;
      FileIException error;
      if (ret == 0) throw error;
      _rootname[_grouplevel+1] = _current_objectname;
      idx[_grouplevel+1] = 0;
   }
   catch (FileIException error)
   {
      // since iterElems gave an exception
      // we have iterated over all elements in the current group.
      // we hence need to iterate to the next group on the lower level
      // and continue iterating on the current grouplevel.
      // If we are on a higher grouplevel then we have metadata matching by identifier
      // we are done.
      int start_at_grouplevel = 1;
      int success = 1;
      do {
         if (_by_identifier.size() > 0 && _grouplevel >= _by_identifier.size())
         {
            done = true;
            return *this;
         }
         bool go_to_next_grouplevel = true;
         for (int i=start_at_grouplevel; i <= _grouplevel; ++i)
         {
            int success;
            try {
               _cur_H5iter_grouplevel = 0;
               //cout << _grouplevel-i << endl;
               success = file.iterateElems(_rootname[_grouplevel-i], &idx[_grouplevel-i], H5iter, this);
               FileIException error;
               if (!success) throw error;
               _rootname[_grouplevel-i+1] = _current_objectname;
               idx[_grouplevel-i+1] = 0;
               go_to_next_grouplevel = false;
               start_at_grouplevel = i-1;
               //cout << "hurray" << endl;
               break;
            }
            catch (FileIException error)
            {
            }
            start_at_grouplevel = 1;
         }
         // if all elements on the current grouplevel have been iterated over,
         // we need to go to the next higher grouplevel
	 if (go_to_next_grouplevel)
	 {
	    //cout << "going to next group level ..." << endl;
            //cout << "maxgrouplevel = " << maxgrouplevel << endl;
	    _grouplevel++;
	    if (_grouplevel > maxgrouplevel || (_by_identifier.size() > 0 && _grouplevel > _by_identifier.size()))
	    {
	       done = true;
	       return *this;
	    }
	    idx[_grouplevel] = 0;
	    for (int i=0; i < _grouplevel; ++i)
	    {
	       idx[i] = 0;
	       _cur_H5iter_grouplevel = 0;
	       ret = file.iterateElems(_rootname[i], &idx[i], H5iter, this);
	       _rootname[i+1] = _current_objectname;
	    }
	 }
	 success = 1;
	 try {
	    _cur_H5iter_grouplevel = _grouplevel;
	    do {
	       success = file.iterateElems(_rootname[_grouplevel], &idx[_grouplevel], H5iter, this);
	    } while (success == 2);
	 }
	 catch (FileIException error)
	 {
	    success = 0;
	 }
         //cout << "redo" << endl;
      } while (!success);
   }

   return *this;
}


bool CarpetN5::Iterator::conforms_with_identifier(const metadata& md, const string& fullname)
{
   string name = fullname;
   string tmp;
   size_t pos;
   attribute<int> ia;
   attribute<string> sa;
   metadata md_found;
   
   if (md.size() == 0) return true;
   
   // all groups/objects are separated by '/', so we go through
   // each of the sub-strings conatined between two '/' and check
   // if it matches with all identifiers that are provided in the metadata
   while ((pos = name.find_first_of("/")) != string::npos)
   {
      name.erase(0, pos+1);
      // only operate on name before seperator
      tmp = name;
      size_t separator_pos = tmp.find("=");
      // if this is a group without separators. Ignore it.
      if (separator_pos == string::npos) continue;
      tmp.erase(separator_pos);

      bool found = false;
      while (!found)
      {
         md >> ia;
         if (ia.valid())
         {
            if ((pos = tmp.find(ia.identifier())) != string::npos)
            {
               found = true;
               md_found << ia;
            }
         }
         else break;
      }
      
      while (!found)
      {
         md >> sa;
         if (sa.valid())
         {
            if ((pos = tmp.find(sa.identifier())) != string::npos)
            {
               found = true;
               md_found << sa;
            }
         }
         else break;
      }
      
      md.reset_stream();
      
      if (!found) 
      {
         // We are on an object with invalid metadata.
         // Since all deeper levels will also be invalid then, we speed things up by not iterating over
         // deeper levels by resetting maxgrouplevels
         //maxgrouplevel = _grouplevel;
         return false; 
      }
   }
   
   // we must find all metadata requested
   if (md.size() == md_found.size())
      return true;
   
   // We are on an object with incomplete metadata.
   // However, it can be that a deeper level contains the missing information.
   //maxgrouplevel = _grouplevel + 1;
   return false;
}


bool CarpetN5::Iterator::conforms_with_value(const metadata& md, const string& fullname)
{
   string name = fullname;
   string tmp;
   size_t pos;
   attribute<int> ia;
   attribute<string> sa;
   metadata md_found;
   
   if (md.size() == 0) return true;
   
   // all groups/objects are separated by '/', so we go through
   // each of the sub-strings conatined between two '/' and check
   // if it matches with all identifiers that are provided in the metadata
   // In addition, we check if all values are matching!
   while ((pos = name.find_first_of("/")) != string::npos)
   {
      name.erase(0, pos+1);
      // only operate on name before next "/"
      tmp = name;
      //cout << tmp << endl;
      size_t separator_pos = tmp.find("/");
      if (separator_pos != string::npos) tmp.erase(separator_pos);
      string val = tmp;
      separator_pos = tmp.find("=");
      // if this is a group without separators. Ignore it.
      if (separator_pos == string::npos) continue;
      tmp.erase(separator_pos);
      val.erase(0, separator_pos+1);
      //cout << val << endl;
      
      //cout << tmp << " = " << valstream.str() << endl;
      bool found = false;
      while (!found)
      {
         md >> ia;
         if (ia.valid())
         {
            if ((pos = tmp.find(ia.identifier())) != string::npos && !md_found.QueryAttribute<int>(ia.identifier()).valid())
            {
               stringstream valstream;
               valstream << val;
               int i;
               valstream >> i;
               //cout << ia.identifier() << " = " << ia.value() << endl;
               if (i == ia.value())
               {
                  found = true;
                  md_found << ia;
               }
            }
         }
         else break;
      }
      
      while (!found)
      {
         md >> sa;
         if (sa.valid())
         {
            if ((pos = tmp.find(sa.identifier())) != string::npos && !md_found.QueryAttribute<int>(ia.identifier()).valid())
            {
               if (val == sa.value())
               {
                  found = true;
                  md_found << sa;
               }
            }
         }
         else break;
      }
      
      md.reset_stream();
      
   }
   
   // we must find all metadata requested
   if (md.size() == md_found.size())
      return true;
   
   return false;
}


void CarpetN5::Iterator::getMetadata()
{
   // could speed this up by 
   // caching metadata from lower grouplevels.

   // clear current metadata
   _md = metadata();

   // get metadata of all lower grouplevels
   for (int i=0; i <= _grouplevel; ++i)
   {
      string objname = _rootname[i];
      addMetadata(objname);
   }
   // add metadata of current object
   addMetadata(_current_objectname);
}


void CarpetN5::Iterator::addMetadata(const string& objname)
{
   attribute<int> ia;
   attribute<vector<int> > iva;
   attribute<fp> fa;
   attribute<vector<fp> > fva;
   attribute<string> sa;

   // open current Group
   //cout << objname << endl;
   Group group = file.openGroup(objname);

   // iterate over all attributes in the current group and add it to
   // the metadata
   const int nattribs = group.getNumAttrs();
   for (int i = 0; i < nattribs; ++i)
   {
      Attribute H5Attr = group.openAttribute(i);
      //cout << H5Attr.getName() << endl;
      
      DataSpace dspace = H5Attr.getSpace();
      H5T_class_t type = H5Attr.getTypeClass();
      
      if (type == PredType::NATIVE_INT.getClass())
      {
         vector<int> vi(dspace.getSimpleExtentNpoints());
         H5Attr.read(PredType::NATIVE_INT, &vi.front());
         
         if (vi.size() == 1) {
            ia = attribute<int>(H5Attr.getName(), vi[0]);
            _md << ia;
         }
         else {
            iva = attribute<vector<int> >(H5Attr.getName(), vi);
            _md << iva;
         }
      }
      
      if (type == PredType::NATIVE_DOUBLE.getClass())
      {
         vector<fp> vf(dspace.getSimpleExtentNpoints());
         H5Attr.read(PredType::NATIVE_DOUBLE, &vf.front());
         
         if (vf.size() == 1) {
            fa = attribute<fp>(H5Attr.getName(), vf[0]);
            _md << fa;
         }
         else {
            fva = attribute<vector<fp> >(H5Attr.getName(), vf);
            _md << fva;
         }
      }
      
      if (type == PredType::C_S1.getClass())
      {
         char val[1000];
         H5Attr.read(StrType(PredType::C_S1, 1000), val);
         
         sa = attribute<string>(H5Attr.getName(), val);
         _md << sa;
      }
   }
}




void CarpetN5::Iterator::jumpToObject(const metadata& _by_value)
{
   attribute<int> ia;
   attribute<string> sa;
   
   if ((ia = _by_value.QueryAttribute<int>("cycle")).valid())
   {
      ostringstream str;
      str << ia.identifier() << "=" << ia.value();
      _grouplevel = 0;
      _rootname[_grouplevel+1] = "/" + str.str();
      _cur_H5iter_grouplevel = 0;
      for (int i=0; i < file.getNumObjs(); ++i)
      {
         if (file.getObjnameByIdx(i) == str.str()) {
            idx[_grouplevel] = i;
            break;
         }
      }
   }
   else return;
   
   if ((ia = _by_value.QueryAttribute<int>("timelevel")).valid())
   {
      jumpToObjectHelper(ia);
   }
   else return;
   
   if ((sa = _by_value.QueryAttribute<string>("meshname")).valid())
   {
      jumpToObjectHelper(sa);
   }
   else return;
   
   if ((ia = _by_value.QueryAttribute<int>("map")).valid())
   {
      jumpToObjectHelper(ia);
   }
   else return;
   
   if ((ia = _by_value.QueryAttribute<int>("reflevel")).valid())
   {
      jumpToObjectHelper(ia);
   }
   else return;
}






} // namespace
