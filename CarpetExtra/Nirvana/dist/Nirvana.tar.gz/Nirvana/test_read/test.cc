
#include "CarpetN5.hh"
#include "metadata.hh"
#include <vector>

using namespace Nirvana;
using namespace std;



int main()
{
   //CarpetN5 io("cactus-simulation-output", false, 1, false);
   CarpetN5 io("test_out", false, 1, false);
   cout << "number of cycles = " << io.GetCycles().size() << endl;
   
   
   // the metadata describing the mesh
   metadata md;
   
   attribute<int> acycle("cycle", 0);
   attribute<int> areflevel("reflevel", 0);
   attribute<int> atimelevel("timelevel", 0);
   attribute<int> amap("map", 0);
   attribute<int> afilenum("filenum", 0);
   attribute<double> atime("time", 0);
   attribute<vector<int> > alsh("lsh", vector<int>(3, 10));
   attribute<vector<int> > aiorigin("iorigin", vector<int>(3, 0));
   attribute<vector<double> > aorigin("origin", vector<double>(3, 0));
   attribute<vector<double> > adelta("delta", vector<double>(3, 0));
   attribute<int> acomp("comp", 0);
   attribute<string> ameshname("meshname", "Carpet-AMR");
   attribute<string> acoordinates("coordinates", "none");
   attribute<string> avarname("varname", "r");
   attribute<string> avargroupname("vargroupname", "grid");
   attribute<string> avargrouptype("vargrouptype", "scalar");

   
   // Append attributes to metadata
   md << afilenum;      // the filenumber that contains the data
   md << ameshname;     // the name of the mesh
   md << acycle;        // the current cycle/iteration
   md << atime;         // the time corresponding to cycle
   md << amap;          // the map
   md << areflevel;     // the refinement level
   md << atimelevel;    // the time level
   md << acomp;         // the grid component
   md << alsh;          // the number of points of the local piece of grid data
   md << aiorigin;      // the integer origin of the grid
   md << aorigin;       // the origin in coordinate space
   md << adelta;        // the delta spacing
   md << acoordinates;  // the name of the coordinate group

   md << avarname;      // the name of the variable
   md << avargroupname; // the name of the variable's group
   md << avargrouptype; // the type of the variable's group
   
   
   // a data buffer
   vector<double> buffer(1000, 1);
   
   // iterating over some metadata
   attribute<int> acycles("cycle", 1);
   attribute<int> atl("timelevel", 0);
   attribute<int> arl("reflevel", 0);
   metadata md2;
   md2 << acycles;
   md2 << ameshname;
   //md2 << avargrouptype;
   md2 << amap;
   md2 << atl;
   //md2 << arl;
   metadata md_by_value;
   //md_by_value << arl;
   md_by_value << acycles;
   md_by_value << atl;
   md_by_value << ameshname; //attribute<string>("meshname", "bla");
   md_by_value << amap;
   
   int i = 0;
   for (CarpetN5::Iterator iCycles = io.Begin(md2, md_by_value, false); !iCycles.Done(); ++iCycles)
   {
      cout << iCycles.current_objectname() << endl;
      
      metadata md3 = *iCycles;
      int cycle = md3.QueryAttribute<int>("cycle").value();
      fp time = md3.QueryAttribute<fp>("time").value();
      cout << "cycle = " << cycle << endl;
      cout << "time = " << time << endl;
      
      cout << "-----------------------------------------------------------------------------------------------------------" << endl;
      i++;
   }
   

}

