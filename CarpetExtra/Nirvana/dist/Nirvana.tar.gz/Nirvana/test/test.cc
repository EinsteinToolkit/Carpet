
#include "CarpetN5.hh"
#include "metadata.hh"
#include <vector>

using namespace Nirvana;
using namespace std;



int main()
{
   CarpetN5 io("test_out", false, 1, false);
   
   // the metadata describing the mesh
   metadata md;
   
   attribute<int> acycle("cycle", 0);
   attribute<int> areflevel("reflevel", 0);
   attribute<int> atimelevel("timelevel", 0);
   attribute<int> amap("map", 0);
   attribute<int> afilenum("filenum", 0);
   attribute<double> atime("time", 0);
   attribute<vector<int> > alsh("lsh", vector<int>(3, 10));
   attribute<vector<int> > aiorigin("iorigin", vector<int>(3, 0));
   attribute<vector<double> > aorigin("origin", vector<double>(3, 0));
   attribute<vector<double> > adelta("delta", vector<double>(3, 0));
   attribute<vector<int> > aghosts("delta", vector<int>(3, 0));
   attribute<int> acomp("comp", 0);
   attribute<string> ameshname("meshname", "Carpet-AMR");
   attribute<string> acoordinates("coordinates", "none");
   attribute<string> avarname("varname", "r");
   attribute<string> avargroupname("vargroupname", "grid");
   attribute<string> avargrouptype("vargrouptype", "scalar");

   
   // Append attributes to metadata
   md << afilenum;      // the filenumber that contains the data
   md << ameshname;     // the name of the mesh
   md << acycle;        // the current cycle/iteration
   md << atime;         // the time corresponding to cycle
   md << amap;          // the map
   md << areflevel;     // the refinement level
   md << atimelevel;    // the time level
   md << acomp;         // the grid component
   md << alsh;          // the number of points of the local piece of grid data
   md << aiorigin;      // the integer origin of the grid
   md << aorigin;       // the origin in coordinate space
   md << adelta;        // the delta spacing
   md << acoordinates;  // the name of the coordinate group
   md << aghosts;

   md << avarname;      // the name of the variable
   md << avargroupname; // the name of the variable's group
   md << avargrouptype; // the type of the variable's group
   
   
   // a data buffer
   vector<double> buffer(1000, 1);
   
   // Write mesh to root file and create link to actual file containing that mesh.
   // This will generate the HDF5 group structure
   // for the current timestep based on the provided metadata.
   // This is not necessary in practice since if all metadata are provided correctly
   // WriteField will execute this function.
   io.WriteMesh(md);
   
   // Write mesh of process 0 to disk.
   // This will generate the HDF5 group structure
   // for the current timestep based on the provided metadata.
   // This is not necessary in practice since if all metadata are provided correctly
   // WriteField will execute this function.
   io.WriteMesh(md, 0);
   
   // Create symlink of data in root file. The metadata defines in which file the data
   // is located.
   // The metadata knows via the attribute 'meshname' to which mesh it must be attached.
   // However, if the mesh does not exist yet we execute WriteMesh.
   io.WriteField<double>(md, buffer);
   
   // Write actual data to file 0
   io.WriteField<double>(md, buffer, 0);
   
   
   metadata md2;
   md2 << afilenum;      // the filenumber that contains the data
   md2 << ameshname;     // the name of the mesh
   md2 << attribute<int>("cycle", 1);        // the current cycle/iteration
   md2 << attribute<fp>("time", 0.5);         // the time corresponding to cycle
   md2 << amap;          // the map
   md2 << areflevel;     // the refinement level
   md2 << atimelevel;    // the time level
   md2 << acomp;         // the grid component
   md2 << alsh;          // the number of points of the local piece of grid data
   md2 << aiorigin;      // the integer origin of the grid
   md2 << aorigin;       // the origin in coordinate space
   md2 << adelta;        // the delta spacing
   md2 << acoordinates;  // the name of the coordinate group

   md2 << avarname;      // the name of the variable
   md2 << avargroupname; // the name of the variable's group
   md2 << avargrouptype; // the type of the variable's group

   io.WriteMesh(md2);
   
   io.WriteMesh(md2, 0);
   
   io.WriteField<double>(md2, buffer);
   
   io.WriteField<double>(md2, buffer, 0);
}

